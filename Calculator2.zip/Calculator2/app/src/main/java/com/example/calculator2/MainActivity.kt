package com.example.calculator2

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    lateinit var btnAdd : Button

    lateinit var btnSub : Button

    lateinit var btnTimes : Button

    lateinit var btnDivide : Button

    lateinit var etNum1 : EditText

    lateinit var etNum2 : EditText
    lateinit var results : TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        btnAdd = findViewById<Button>(R.id.btn_add)
        btnSub = findViewById<Button>(R.id.btn_substract)
        btnTimes = findViewById<Button>(R.id.btn_mutilple)
        btnDivide = findViewById<Button>(R.id.btn_divide)

        etNum1 = findViewById<EditText>(R.id.et_num1)
        etNum2 = findViewById<EditText>(R.id.et_num2)
        results = findViewById<TextView>(R.id.tv_Answer)

    }
    }
